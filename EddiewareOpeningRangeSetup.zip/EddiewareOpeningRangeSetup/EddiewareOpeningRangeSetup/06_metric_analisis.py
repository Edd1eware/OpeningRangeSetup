# -*- coding: utf-8 -*-
from pathlib import Path
import re
import statistics

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


# ============================================================
# CONFIG
# ============================================================

FOOTPRINT_DIR = Path(
    r"C:\Users\k_99_\Desktop\codding\data_footprint_generator\footprints_generados"
)
OUTPUT_XLSX = Path(__file__).with_name("metric results.xlsx")

OPENING_CANDLE_TIME = "09:30"
TICK_SIZE = 0.25
MIN_CONTINUATION_TICKS = 60
MIN_TRADE_TICKS = 60
MAX_TRADE_TICKS = 120

COLOR_FOOTPRINT_FILES = False
PROFIT_ZONE_FILL = "C6EFCE"
RISK_ZONE_FILL = "FFC7CE"
ENTRY_LINE_COLOR = "7030A0"
SL_LINE_COLOR = "C00000"
TP_LINE_COLOR = "00B050"
ENTRY_MARKER_FILL = "FFE699"
SL_MARKER_FILL = "FF0000"
TP_MARKER_FILL = "00B050"

BODY_FILLS = {
    "C6EFCE",
    "FFC7CE",
}
BODY_BORDER_COLORS = {
    "00B050",
    "C00000",
}
BULLISH_BODY_COLORS = {"C6EFCE", "00B050"}
BEARISH_BODY_COLORS = {"FFC7CE", "C00000"}
VOLUME_RE = re.compile(r"^\s*\d+\s*x\s*\d+\s*$", re.IGNORECASE)


# ============================================================
# HELPERS
# ============================================================

def detect_date_from_filename(path):
    match = re.search(r"(\d{4}-\d{2}-\d{2})", path.name)
    return match.group(1) if match else path.stem


def round_to_tick(value):
    return round(float(value) / TICK_SIZE, 2)


def ticks_to_points(ticks):
    return float(ticks) * TICK_SIZE


def clamp_ticks(ticks, min_ticks=MIN_TRADE_TICKS, max_ticks=MAX_TRADE_TICKS):
    return max(min_ticks, min(float(ticks), max_ticks))


def safe_mean(values):
    values = [v for v in values if v is not None]
    return statistics.mean(values) if values else None


def trade_risk_ticks(row):
    entry = row.get("entry_price")
    sl = row.get("SL_price")
    if entry is None or sl is None:
        return None
    return round_to_tick(abs(float(entry) - float(sl)))


def calculate_profit_factor(rows):
    gross_profit = 0.0
    gross_loss = 0.0

    for row in rows:
        if not row.get("filter_taken"):
            continue

        risk_ticks = trade_risk_ticks(row)
        if risk_ticks is None:
            continue

        if row.get("continuation_60t"):
            gross_profit += risk_ticks
        else:
            gross_loss += risk_ticks

    if gross_loss == 0:
        return "INF" if gross_profit > 0 else None

    return gross_profit / gross_loss


def rgb(color):
    if color is None:
        return None
    if color.type == "rgb":
        value = color.rgb
        if value and len(value) == 8:
            return value[-6:]
        return value
    return None


def is_volume_cell(value):
    return isinstance(value, str) and bool(VOLUME_RE.match(value))


def is_body_cell(cell):
    left = cell.border.left
    right = cell.border.right
    left_rgb = rgb(left.color)
    right_rgb = rgb(right.color)

    return (
        (left.style == "medium" and left_rgb in BODY_BORDER_COLORS)
        or (right.style == "medium" and right_rgb in BODY_BORDER_COLORS)
    )


def body_direction(cell):
    colors = [
        rgb(cell.border.left.color),
        rgb(cell.border.right.color),
    ]
    if any(color in BULLISH_BODY_COLORS for color in colors):
        return "BUY"
    if any(color in BEARISH_BODY_COLORS for color in colors):
        return "SELL"
    return None


def find_minute_column(ws, minute):
    for cell in ws[2]:
        if str(cell.value).strip() == minute:
            return cell.column
    return None


def nearest_price_row(price_rows, target_price):
    if target_price is None or not price_rows:
        return None
    return min(price_rows, key=lambda item: abs(item[1] - float(target_price)))[0]


def get_minute_columns(ws):
    minute_columns = []
    for cell in ws[2]:
        value = str(cell.value or "").strip()
        if re.match(r"^\d{2}:\d{2}$", value):
            minute_columns.append((value, cell.column))
    return minute_columns


def find_label_row(ws, label):
    target = str(label).strip().lower()
    for row_idx in range(1, ws.max_row + 1):
        value = ws.cell(row=row_idx, column=1).value
        if str(value or "").strip().lower() == target:
            return row_idx
    return None


def read_metric_by_minute(ws, minute_columns, label):
    label_row = find_label_row(ws, label)
    if label_row is None:
        return {}

    return {
        minute: ws.cell(row=label_row, column=minute_col).value
        for minute, minute_col in minute_columns
    }


def iter_price_rows(ws):
    for row_idx in range(3, ws.max_row + 1):
        price = ws.cell(row=row_idx, column=1).value
        if price in (None, "", "VWAP", "Métrica", "Delta", "Volumen"):
            continue

        try:
            yield row_idx, float(price)
        except (TypeError, ValueError):
            continue


def read_candle(ws, minute, minute_col):
    traded_prices = []
    body_prices = []
    directions = []

    for row_idx, price in iter_price_rows(ws):
        cell = ws.cell(row=row_idx, column=minute_col)

        if is_volume_cell(cell.value):
            traded_prices.append(price)

        if is_body_cell(cell):
            body_prices.append(price)
            direction = body_direction(cell)
            if direction:
                directions.append(direction)

    if not traded_prices:
        return None

    high = max(traded_prices)
    low = min(traded_prices)
    range_points = high - low
    range_ticks = round_to_tick(range_points)

    body_ticks = None
    body_pct = None
    body_high = None
    body_low = None
    direction = None
    close = None

    if body_prices and range_points > 0:
        body_high = max(body_prices)
        body_low = min(body_prices)
        body_ticks = round_to_tick(body_high - body_low)
        body_pct = (body_ticks / range_ticks) * 100 if range_ticks else 0

        if directions:
            direction = max(set(directions), key=directions.count)
            close = body_high if direction == "BUY" else body_low

    return {
        "minute": minute,
        "low": low,
        "high": high,
        "range_points": range_points,
        "range_ticks": range_ticks,
        "body_low": body_low,
        "body_high": body_high,
        "body_ticks": body_ticks,
        "body_pct": body_pct,
        "direction": direction,
        "close": close,
    }


def find_breakout_signal(candles, opening_candle):
    or_high = opening_candle["high"]
    or_low = opening_candle["low"]
    minutes = sorted(candles)

    for idx, minute in enumerate(minutes):
        if minute <= OPENING_CANDLE_TIME:
            continue
        if idx + 1 >= len(minutes):
            break

        candle = candles[minute]
        next_minute = minutes[idx + 1]
        next_candle = candles[next_minute]
        direction = candle.get("direction")
        close = candle.get("close")

        if direction == "BUY" and close is not None and close > or_high:
            breakout_ticks = round_to_tick(close - or_high)
            continuation_ticks = round_to_tick(next_candle["high"] - close)
            return {
                "breakout_time": minute,
                "breakout_side": "BUY",
                "breakout_body_price": close,
                "breakout_body_ticks": breakout_ticks,
                "next_candle_time": next_minute,
                "next_continuation_ticks": continuation_ticks,
                "continuation_60t": continuation_ticks >= MIN_CONTINUATION_TICKS,
            }

        if direction == "SELL" and close is not None and close < or_low:
            breakout_ticks = round_to_tick(or_low - close)
            continuation_ticks = round_to_tick(close - next_candle["low"])
            return {
                "breakout_time": minute,
                "breakout_side": "SELL",
                "breakout_body_price": close,
                "breakout_body_ticks": breakout_ticks,
                "next_candle_time": next_minute,
                "next_continuation_ticks": continuation_ticks,
                "continuation_60t": continuation_ticks >= MIN_CONTINUATION_TICKS,
            }

    return {
        "breakout_time": None,
        "breakout_side": None,
        "breakout_body_price": None,
        "breakout_body_ticks": None,
        "next_candle_time": None,
        "next_continuation_ticks": None,
        "continuation_60t": False,
    }


def add_breakout_metrics(breakout, volume_by_minute, delta_by_minute, vwap_by_minute):
    breakout_time = breakout.get("breakout_time")
    if not breakout_time:
        breakout.update(
            {
                "breakout_volume": None,
                "breakout_delta": None,
                "breakout_vwap": None,
            }
        )
        return breakout

    breakout.update(
        {
            "breakout_volume": volume_by_minute.get(breakout_time),
            "breakout_delta": delta_by_minute.get(breakout_time),
            "breakout_vwap": vwap_by_minute.get(breakout_time),
        }
    )
    return breakout


def to_minutes(time_text):
    if not time_text:
        return None
    parts = str(time_text).strip().split(":")
    if len(parts) < 2:
        return None
    try:
        return int(parts[0]) * 60 + int(parts[1])
    except ValueError:
        return None


def get_breakout_imbalance_signal(wb, breakout_time, breakout_side, breakout_candle):
    result = {
        "Imbalance detected": False,
        "imbalance_price": None,
        "imbalance_zone": "",
    }

    if not breakout_time or breakout_side not in {"BUY", "SELL"}:
        return result
    if not breakout_candle:
        return result
    if "ImbalanceCandidates" not in wb.sheetnames:
        return result

    ws = wb["ImbalanceCandidates"]
    headers = {
        str(ws.cell(row=1, column=col).value or "").strip().lower(): col
        for col in range(1, ws.max_column + 1)
    }
    minute_col = headers.get("minute")
    side_col = headers.get("side")
    price_col = headers.get("price")
    if minute_col is None or side_col is None or price_col is None:
        return result

    midpoint = (breakout_candle["high"] + breakout_candle["low"]) / 2

    for row_idx in range(2, ws.max_row + 1):
        minute = str(ws.cell(row=row_idx, column=minute_col).value or "").strip()
        side = str(ws.cell(row=row_idx, column=side_col).value or "").strip().upper()
        if minute != breakout_time or side != breakout_side:
            continue

        try:
            price = float(ws.cell(row=row_idx, column=price_col).value)
        except (TypeError, ValueError):
            continue

        if breakout_side == "BUY" and price >= midpoint:
            result["Imbalance detected"] = True
            result["imbalance_price"] = price
            result["imbalance_zone"] = "UPPER_50"
            return result

        if breakout_side == "SELL" and price <= midpoint:
            result["Imbalance detected"] = True
            result["imbalance_price"] = price
            result["imbalance_zone"] = "LOWER_50"
            return result

    return result


def add_trade_simulation(row):
    side = row.get("breakout_side")
    entry_price = row.get("breakout_body_price")

    if side == "BUY" and entry_price is not None:
        trade_ticks = clamp_ticks(round_to_tick(entry_price - row.get("or_low")))
        trade_points = ticks_to_points(trade_ticks)
        row["entry_time"] = row.get("breakout_time")
        row["entry_price"] = entry_price
        row["SL_price"] = entry_price - trade_points
        row["TP_price"] = entry_price + trade_points
    elif side == "SELL" and entry_price is not None:
        trade_ticks = clamp_ticks(round_to_tick(row.get("or_high") - entry_price))
        trade_points = ticks_to_points(trade_ticks)
        row["entry_time"] = row.get("breakout_time")
        row["entry_price"] = entry_price
        row["SL_price"] = entry_price + trade_points
        row["TP_price"] = entry_price - trade_points
    else:
        row["entry_time"] = None
        row["entry_price"] = None
        row["SL_price"] = None
        row["TP_price"] = None

    return row


def delta_aligned_with_side(row):
    delta = row.get("breakout_delta")
    side = row.get("breakout_side")
    if delta is None or side not in {"BUY", "SELL"}:
        return False
    return (side == "BUY" and delta > 0) or (side == "SELL" and delta < 0)


def vwap_aligned_with_side(row):
    entry = row.get("entry_price")
    vwap = row.get("breakout_vwap")
    side = row.get("breakout_side")
    if entry is None or vwap is None or side not in {"BUY", "SELL"}:
        return False
    return (side == "BUY" and entry >= vwap) or (side == "SELL" and entry <= vwap)


def vwap_distance_ticks(row):
    entry = row.get("entry_price")
    vwap = row.get("breakout_vwap")
    if entry is None or vwap is None:
        return None
    return round_to_tick(abs(float(entry) - float(vwap)))


def passes_operation_filter(row):
    distance_from_vwap = vwap_distance_ticks(row)

    return (
        row.get("status") == "OK"
        and row.get("breakout_time") is not None
        and to_minutes(row.get("breakout_time")) is not None
        and to_minutes(row.get("breakout_time")) >= to_minutes("09:32")
        and row.get("breakout_side") in {"BUY", "SELL"}
        and row.get("breakout_body_ticks") is not None
        and row.get("breakout_volume") is not None
        and row.get("breakout_delta") is not None
        and row.get("breakout_vwap") is not None
        and row.get("breakout_body_ticks") > 0
        and row.get("Imbalance detected") is True
        and vwap_aligned_with_side(row)
    )


def passes_continuation_filter(row):
    return passes_operation_filter(row)


def detect_operation_setup(row):
    if passes_operation_filter(row):
        return "OPENING_RANGE_CONTINUATION_V1"

    return ""


def detect_trade_classification(row):
    setup = row.get("Setup")
    if setup == "OPENING_RANGE_CONTINUATION_V1":
        return "CONTINUATION"

    return ""


def analyze_opening_candle(path):
    wb = load_workbook(path, read_only=False, data_only=True)
    if "Footprint" not in wb.sheetnames:
        raise ValueError("No existe la hoja 'Footprint'.")

    ws = wb["Footprint"]
    minute_columns = get_minute_columns(ws)
    candles = {}
    for minute, minute_col in minute_columns:
        candle = read_candle(ws, minute, minute_col)
        if candle:
            candles[minute] = candle

    opening_candle = candles.get(OPENING_CANDLE_TIME)
    if opening_candle is None:
        raise ValueError(f"No hay datos de volumen en {OPENING_CANDLE_TIME}.")

    breakout = find_breakout_signal(candles, opening_candle)
    volume_by_minute = read_metric_by_minute(ws, minute_columns, "Volumen")
    delta_by_minute = read_metric_by_minute(ws, minute_columns, "Delta")
    vwap_by_minute = read_metric_by_minute(ws, minute_columns, "VWAP")
    breakout = add_breakout_metrics(
        breakout,
        volume_by_minute,
        delta_by_minute,
        vwap_by_minute,
    )
    imbalance_signal = get_breakout_imbalance_signal(
        wb,
        breakout.get("breakout_time"),
        breakout.get("breakout_side"),
        candles.get(breakout.get("breakout_time")),
    )
    breakout.update(imbalance_signal)

    row = {
        "date": detect_date_from_filename(path),
        "file": path.name,
        "minute": OPENING_CANDLE_TIME,
        "or_low": opening_candle["low"],
        "or_high": opening_candle["high"],
        "range_points": opening_candle["range_points"],
        "range_ticks": opening_candle["range_ticks"],
        "body_low": opening_candle["body_low"],
        "body_high": opening_candle["body_high"],
        "body_ticks": opening_candle["body_ticks"],
        "body_pct": opening_candle["body_pct"],
        **breakout,
        "status": "OK",
        "error": "",
    }
    row = add_trade_simulation(row)
    row["Setup"] = detect_operation_setup(row)
    row["Trade_Clasification"] = detect_trade_classification(row)
    row["Operation"] = "TRADE" if row["Setup"] else "NO TRADE"
    return row


def format_number(value, digits=2):
    if value is None:
        return ""
    return f"{value:.{digits}f}"


def write_excel(rows, summary):
    headers = [
        "date",
        "file",
        "minute",
        "or_low",
        "or_high",
        "range_points",
        "range_ticks",
        "body_low",
        "body_high",
        "body_ticks",
        "body_pct",
        "breakout_time",
        "breakout_side",
        "breakout_body_price",
        "breakout_body_ticks",
        "breakout_volume",
        "breakout_delta",
        "breakout_vwap",
        "Imbalance detected",
        "imbalance_price",
        "imbalance_zone",
        "Setup",
        "Trade_Clasification",
        "Operation",
        "entry_time",
        "entry_price",
        "SL_price",
        "TP_price",
        "next_candle_time",
        "next_continuation_ticks",
        "continuation_60t",
        "filter_taken",
        "status",
        "error",
    ]

    wb = Workbook()
    ws_summary = wb.active
    ws_summary.title = "Summary"
    ws_detail = wb.create_sheet("Detail")

    header_fill = PatternFill("solid", fgColor="D9EAF7")
    ok_fill = PatternFill("solid", fgColor="C6EFCE")
    error_fill = PatternFill("solid", fgColor="FFC7CE")

    ws_summary["A1"] = "Metric Results - Vela 09:30"
    ws_summary["A1"].font = Font(bold=True, size=14)
    ws_summary["A1"].fill = header_fill
    ws_summary.merge_cells("A1:B1")

    summary_rows = [
        ("Archivos analizados OK", summary["ok_files"]),
        ("Archivos totales", summary["total_files"]),
        ("Promedio rango vela 09:30 (ticks)", summary["avg_range_ticks"]),
        ("Promedio body vela 09:30 (ticks)", summary["avg_body_ticks"]),
        ("Promedio % body vela 09:30", summary["avg_body_pct"]),
        ("Continuaciones simples >= 60 ticks", summary["continuation_count"]),
        ("% continuaciones simples >= 60 ticks", summary["continuation_pct"]),
        ("Promedio breakout con cuerpo (ticks)", summary["avg_breakout_body_ticks"]),
        ("Trades tomados con filtro", summary["filter_taken_count"]),
        ("% trades tomados con filtro", summary["filter_taken_pct"]),
        ("Winrate filtro sin lookahead", summary["filter_winrate_pct"]),
        ("% continuaciones capturadas por filtro", summary["filter_capture_pct"]),
        ("Profit factor filtro", summary["profit_factor"]),
        ("Filtro usado", summary["filter_rule"]),
        ("Ruta analizada", str(FOOTPRINT_DIR)),
    ]

    for row_idx, (label, value) in enumerate(summary_rows, start=3):
        ws_summary.cell(row=row_idx, column=1, value=label).font = Font(bold=True)
        ws_summary.cell(row=row_idx, column=2, value=value)

    for row_idx in range(3, 3 + len(summary_rows)):
        if ws_summary.cell(row=row_idx, column=1).value == "% trades tomados con filtro":
            ws_summary.cell(row=row_idx, column=3, value="equivale a trades").font = Font(bold=True)
            ws_summary.cell(row=row_idx, column=4, value=summary["filter_taken_count"]).font = Font(bold=True)
            ws_summary.cell(row=row_idx, column=4).fill = ok_fill
            break

    percent_labels = {
        "Promedio % body vela 09:30",
        "% continuaciones simples >= 60 ticks",
        "% trades tomados con filtro",
        "Winrate filtro sin lookahead",
        "% continuaciones capturadas por filtro",
    }

    for row_idx in range(3, 3 + len(summary_rows)):
        label = ws_summary.cell(row=row_idx, column=1).value
        value_cell = ws_summary.cell(row=row_idx, column=2)
        if label in percent_labels and isinstance(value_cell.value, (int, float)):
            value_cell.value = value_cell.value / 100
            value_cell.number_format = "0.00%"
        elif isinstance(value_cell.value, float):
            value_cell.number_format = "0.00"

    for col_idx, header in enumerate(headers, start=1):
        cell = ws_detail.cell(row=1, column=col_idx, value=header)
        cell.font = Font(bold=True)
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center")

    for row_idx, row in enumerate(rows, start=2):
        for col_idx, header in enumerate(headers, start=1):
            value = row.get(header, "")
            cell = ws_detail.cell(row=row_idx, column=col_idx, value=value)
            if header == "body_pct" and isinstance(value, (int, float)):
                cell.value = value / 100
                cell.number_format = "0.00%"
            elif isinstance(value, float):
                cell.number_format = "0.00"

        if row.get("filter_taken"):
            for col_idx in range(1, len(headers) + 1):
                ws_detail.cell(row=row_idx, column=col_idx).fill = ok_fill

        status_cell = ws_detail.cell(row=row_idx, column=headers.index("status") + 1)
        if row.get("filter_taken"):
            status_cell.fill = ok_fill
        else:
            status_cell.fill = ok_fill if row.get("status") == "OK" else error_fill

    for ws in (ws_summary, ws_detail):
        for column in ws.columns:
            max_len = 0
            column_letter = get_column_letter(column[0].column)
            for cell in column:
                max_len = max(max_len, len(str(cell.value or "")))
            ws.column_dimensions[column_letter].width = min(max(max_len + 2, 12), 70)
        ws.freeze_panes = "A2"

    wb.save(OUTPUT_XLSX)


def with_top_border(existing_border, color):
    side = Side(style="thick", color=color)
    return Border(
        left=existing_border.left,
        right=existing_border.right,
        top=side,
        bottom=existing_border.bottom,
        diagonal=existing_border.diagonal,
        diagonal_direction=existing_border.diagonal_direction,
        diagonalUp=existing_border.diagonalUp,
        diagonalDown=existing_border.diagonalDown,
        outline=existing_border.outline,
        vertical=existing_border.vertical,
        horizontal=existing_border.horizontal,
    )


def color_trade_on_footprint(row):
    if not row.get("filter_taken"):
        return False

    path = FOOTPRINT_DIR / row["file"]
    if not path.exists() or path.name.startswith("~$"):
        return False

    wb = load_workbook(path, read_only=False, data_only=False)
    if "Footprint" not in wb.sheetnames:
        return False

    ws = wb["Footprint"]
    minute_columns = get_minute_columns(ws)
    entry_time = row.get("entry_time")
    entry_col = find_minute_column(ws, entry_time)
    if entry_col is None:
        return False

    last_minute_col = max(column for _, column in minute_columns)
    price_rows = list(iter_price_rows(ws))
    entry_price = row.get("entry_price")
    sl_price = row.get("SL_price")
    tp_price = row.get("TP_price")
    side = row.get("breakout_side")

    if None in (entry_price, sl_price, tp_price) or side not in {"BUY", "SELL"}:
        return False

    profit_low, profit_high = sorted([float(entry_price), float(tp_price)])
    risk_low, risk_high = sorted([float(entry_price), float(sl_price)])
    profit_fill = PatternFill("solid", fgColor=PROFIT_ZONE_FILL)
    risk_fill = PatternFill("solid", fgColor=RISK_ZONE_FILL)
    entry_fill = PatternFill("solid", fgColor=ENTRY_MARKER_FILL)
    sl_fill = PatternFill("solid", fgColor=SL_MARKER_FILL)
    tp_fill = PatternFill("solid", fgColor=TP_MARKER_FILL)

    for row_idx, price in price_rows:
        if profit_low <= price <= profit_high:
            fill = profit_fill
        elif risk_low <= price <= risk_high:
            fill = risk_fill
        else:
            continue

        for col_idx in range(entry_col, last_minute_col + 1):
            ws.cell(row=row_idx, column=col_idx).fill = fill

    marker_rows = [
        (nearest_price_row(price_rows, entry_price), ENTRY_LINE_COLOR, entry_fill),
        (nearest_price_row(price_rows, sl_price), SL_LINE_COLOR, sl_fill),
        (nearest_price_row(price_rows, tp_price), TP_LINE_COLOR, tp_fill),
    ]

    for marker_row, color, marker_fill in marker_rows:
        if marker_row is None:
            continue
        for col_idx in range(entry_col, last_minute_col + 1):
            cell = ws.cell(row=marker_row, column=col_idx)
            cell.border = with_top_border(cell.border, color)
            if marker_fill is not None:
                cell.fill = marker_fill
                cell.font = Font(color="FFFFFF", bold=True) if color != ENTRY_LINE_COLOR else Font(color="000000", bold=True)

    wb.save(path)
    return True


def color_footprint_files(rows):
    colored = 0
    for row in rows:
        if color_trade_on_footprint(row):
            colored += 1
    return colored


def main():
    files = sorted(
        path for path in FOOTPRINT_DIR.glob("*.xlsx")
        if not path.name.startswith("~$")
    )
    if not files:
        raise SystemExit(f"No se encontraron archivos .xlsx en: {FOOTPRINT_DIR}")

    rows = []
    for path in files:
        try:
            rows.append(analyze_opening_candle(path))
        except Exception as exc:
            rows.append(
                {
                    "date": detect_date_from_filename(path),
                    "file": path.name,
                    "minute": OPENING_CANDLE_TIME,
                    "status": "ERROR",
                    "error": str(exc),
                }
            )

    for row in rows:
        row["filter_taken"] = passes_continuation_filter(row)
        row["Setup"] = detect_operation_setup(row)
        row["Trade_Clasification"] = detect_trade_classification(row)
        row["Operation"] = "TRADE" if row["Setup"] else "NO TRADE"

    ok_rows = [row for row in rows if row.get("status") == "OK"]
    avg_range_ticks = safe_mean([row.get("range_ticks") for row in ok_rows])
    avg_body_pct = safe_mean([row.get("body_pct") for row in ok_rows])
    avg_body_ticks = safe_mean([row.get("body_ticks") for row in ok_rows])
    continuation_rows = [row for row in ok_rows if row.get("continuation_60t")]
    continuation_pct = (len(continuation_rows) / len(ok_rows) * 100) if ok_rows else None
    avg_breakout_body_ticks = safe_mean(
        [row.get("breakout_body_ticks") for row in continuation_rows]
    )
    filter_taken_rows = [row for row in ok_rows if row.get("filter_taken")]
    filter_taken_pct = (len(filter_taken_rows) / len(ok_rows) * 100) if ok_rows else None
    filter_winrate_pct = (
        len([row for row in filter_taken_rows if row.get("continuation_60t")])
        / len(filter_taken_rows)
        * 100
    ) if filter_taken_rows else None
    filter_capture_pct = (
        len([row for row in filter_taken_rows if row.get("continuation_60t")])
        / len(continuation_rows)
        * 100
    ) if continuation_rows else None
    filter_rule = (
        "SIN LOOKAHEAD: Operation=TRADE si hay breakout con cuerpo, "
        "breakout_time>=09:32, Imbalance detected=True en la mitad correcta "
        "de la vela de breakout (BUY upper 50%, SELL lower 50%) "
        "y VWAP a favor del trade (BUY entry>=VWAP, SELL entry<=VWAP). "
        "continuation_60t se usa solo como resultado posterior. "
        "Setup actual: OPENING_RANGE_CONTINUATION_V1; futuros setups pendientes: "
        "REVERSE_ABSORTION, CONTINUATION_PULLBACK, TREND_DAY_RUNNER."
    )
    profit_factor = calculate_profit_factor(ok_rows)
    summary = {
        "ok_files": len(ok_rows),
        "total_files": len(rows),
        "avg_range_ticks": avg_range_ticks,
        "avg_body_ticks": avg_body_ticks,
        "avg_body_pct": avg_body_pct,
        "continuation_count": len(continuation_rows),
        "continuation_pct": continuation_pct,
        "avg_breakout_body_ticks": avg_breakout_body_ticks,
        "filter_taken_count": len(filter_taken_rows),
        "filter_taken_pct": filter_taken_pct,
        "filter_winrate_pct": filter_winrate_pct,
        "filter_capture_pct": filter_capture_pct,
        "profit_factor": profit_factor,
        "filter_rule": filter_rule,
    }

    write_excel(rows, summary)
    colored_files = color_footprint_files(rows) if COLOR_FOOTPRINT_FILES else 0

    print("============================================================")
    print("METRICAS VELA DE APERTURA 09:30")
    print("============================================================")
    print(f"Archivos analizados OK: {len(ok_rows)} / {len(rows)}")
    print(f"Promedio rango vela 09:30: {format_number(avg_range_ticks)} ticks")
    print(f"Promedio body vela 09:30: {format_number(avg_body_ticks)} ticks")
    print(f"Promedio % body vela 09:30: {format_number(avg_body_pct)}%")
    print(
        f"Continuaciones simples >= {MIN_CONTINUATION_TICKS} ticks: "
        f"{len(continuation_rows)} / {len(ok_rows)}"
    )
    print(f"Promedio breakout con cuerpo: {format_number(avg_breakout_body_ticks)} ticks")
    print(
        f"Trades tomados con filtro: {len(filter_taken_rows)} / {len(ok_rows)} "
        f"({format_number(filter_taken_pct)}%)"
    )
    print(f"Profit factor filtro: {profit_factor}")
    if COLOR_FOOTPRINT_FILES:
        print(f"Footprints coloreados: {colored_files}")
    print(f"Excel guardado en: {OUTPUT_XLSX}")

    errors = [row for row in rows if row.get("status") != "OK"]
    if errors:
        print("")
        print("Archivos con error:")
        for row in errors[:20]:
            print(f"- {row['file']}: {row['error']}")
        if len(errors) > 20:
            print(f"- ... {len(errors) - 20} errores mas")


if __name__ == "__main__":
    main()
